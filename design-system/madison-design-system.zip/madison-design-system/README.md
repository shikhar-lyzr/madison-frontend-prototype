Madison is one product for a bank's second line: regulatory change, assurance (control testing) and third parties. This system is the look and the parts every screen is built from. The wireframes say what is on a screen and in what order. This system says how it looks. Wireframe plus this system is the UI, and the clickable prototype (madison-process-model.vercel.app/prototype/) is that sum for the main journeys.

## Using this system

- Load the fonts from Google Fonts: Onest (400 to 800) for everything, Azeret Mono (400 to 600) for ids, counts and dates. `components/bundle.css` imports both.
- Use the CSS variables from `tokens.css` (one per token below, `--you`, `--space-panel-x`, `--shadow-lift`). Never paste a hex value into a component.
- `components/bundle.css` is the component stylesheet. Every class starts `md-` and reads only tokens. Copy it whole, or port a component's rules into your own components, keeping the values.
- Build the light theme. A dark theme (Dusk) is drawn for the core colours on the design canvas but not yet for the full palette here.
- Take the words from the wireframe. This system never adds a word to a screen.

## The one rule: what is yours stands out

Every screen answers who has this item now. The answer decides the look.

- Yours: a raised sheet (`sheet`, `shadow-lift`) and the only teal (`you`) on the screen: the primary button, Needs you, Your task now, the edge on your row.
- Not yours: a flat sheet (`flat` with the `shadow-ring` hairline), no teal.
- Stopped: a raised sheet ringed in `stop` (`shadow-stop`).
- Madison working: the only thing that moves. Its icon turns counter-clockwise, the way its arrows point.

## Colour roles

| Role | Token | Use |
| --- | --- | --- |
| Primary | `you` #0b6e69 | The one action that is yours, and every mark of yours. Text on it is `on-you`. |
| Secondary | `ink`, `ink-2`, `ink-3` on `sheet` | Everything else: text, secondary buttons (white pill on `line`), chosen options. |
| Tertiary | `work` #1b5fa3 | Madison's own work: Madison working, the Ask mark, in-progress counts. |
| Ground | `bg`, `sheet`, `sheet-2`, `flat` | Page, raised sheet, inner panel, flat sheet. |

States each have a strong colour for text and icons, a `-soft` ground behind that text, and a `-deep` tint for a plan bar segment with no words.

| State | Colour | Icon | Words |
| --- | --- | --- | --- |
| Needs you | `you` | needs-you | Needs you, Your task now |
| Waiting on someone | `wait` | waiting | Waiting on David Nkemelu |
| Madison working | `work` | madison-working (spins) | Madison working |
| Stopped | `stop` | stopped, alone | the reason only |
| At risk, late | `risk` | at-risk | At risk, 18 days late |
| On time, covered | `ok` | on-time | On time |
| Not started | `ink-3` | not-started | Not started |

Risk levels: High is `level-high` on `level-high-soft`, Medium is `risk` on `risk-soft`, Low is `wait` on `wait-soft`, each a pill with three signal bars (see RiskLevel).

## Choosing is not acting

A chosen option (a segmented control's choice, the All chip, the page you are on in the rail, a checked toggle) is white or a light tint with a ring, and weight 600. It is never teal and never a dark fill, because a fill reads as an action. Teal is kept for the one thing you can do.

## Type

One family, Onest, in a short scale, and Azeret Mono for anything a person reads as a code.

- `page-title` 24px 700 for a record's name. `task-title` 22px 800 for your task inside its sheet. `card-title` 17px 700, `section-title` 15px 700.
- `body` 13px for tables and label and value rows. `lead` 14px for an action card's line. `meta` 12px for since lines, header facts and plain links. `caption` 11px for a step's sub line.
- `column-head` and `overline`: 11px 600, uppercase, letter-spaced 0.08em and 0.1em.
- Ids (CTL-118, WIR-2026-000015, RUN-2026Q1-CTL118), counts and the dates in a lane are `id`, `id-small` or `count`, in mono.
- Large type takes negative letter-spacing as set in each style. Headings balance their lines.

## Space and layout

- The page frame: the rail (`space-rail` 220px), then `space-page-left` (10px), content, `space-page-right` (52px, room for the drawer tab). Content starts `space-page-top` (18px) down and leaves `space-page-bottom` (96px) under it for the Ask bar.
- Sheets stack `space-panel-gap` (14px) apart, padded `space-panel-y` by `space-panel-x` (16px by 20px).
- Every line inside a sheet starts on its 20px text line. A table's outer cells drop their outside padding so the table's text sits on that same line. An inner panel, a pill or an icon may sit on the line, never a few pixels off it.
- Cards in a grid are `space-grid` (16px) apart and share their footer line: a card's last row is pushed to its foot.
- A page grows with its content and scrolls. Nothing is clipped to the window.

## Surfaces, depth and radius

- Radii: `radius-sheet` 20px for sheets and cards, `radius-drawer` 22px, `radius-inner` 16px for a panel inside a sheet, `radius-card` 14px for chips and small cards, `radius-input` 12px, `radius-pill` for buttons and tracks.
- Depth comes from shadows, never from borders: `shadow-lift` for yours, the `shadow-ring` hairline for flat, `shadow-drawer` for the open drawer, `shadow-glow` under the primary button. A closed drawer casts no shadow.
- No coloured left borders on cards. A row that is yours gets a 3px pill in the gutter left of it (see Table).

## Tables

Soft dashed lines between cells (`grid`, 1px dashes on a 10px period), open at every edge: no outline, no line under the last row, none beside the outer columns. Rows have room (`space-row-y` in a list, 58px on a Home). A row that opens a record is clickable as a whole and ends with a chevron. Text wraps, never ellipsis. No zebra stripes.

## Motion

- Every hover, lift and appear eases with `ease-out` (cubic-bezier(0.22, 1, 0.36, 1)) over 160 to 280ms (`duration-hover`, `duration-press`, `duration-lift`, `duration-appear`). The drawer slides with `ease-drawer` over `duration-drawer`.
- Three things move on their own, and only these: the Madison working icon (one counter-clockwise turn every `duration-spin`), the dashed ring on Madison's current step (`duration-ring`), and the pulse on your current step (`duration-pulse`), with dashes flowing into it (`duration-flow`).
- Respect reduced motion: stop all of it.

## Focus and contrast

- Keyboard focus is a 2px solid `you` outline, 2px out: 5.1:1 on `bg`, 6.1:1 on `sheet`.
- Text pairs meet 4.5:1 except where the notes say: `ink-3` on `bg` is 4.3:1 (keep it on a sheet), `stop` on `stop-soft` 4.2:1 and `risk` on `risk-soft` 4.4:1 (keep that text 12px semibold or larger). The `mark` edge (2.4:1) and the `line` hairline (1.4:1) are below 3:1 for marks: a marked row also says what it is in words, and inputs are found by their label as well as their ring.

## Words on screen

- The wireframe's words, and only those. No helper lines that explain a screen's rule: the rule sits behind an info icon on its count.
- Sentence case everywhere: Your task now, Worth a look, Ask the bank.
- A state's icon says the state. Stopped shows the octagon and the reason, never the word Stopped again.
- Parts of a line are joined by a middle dot: 41 of 45 · 18 days late. A count follows its label: To do 2, New rules 4.
- People by name and role (Margaret Ellison, Head of Payment Operations). Placeholders keep their brackets ([date], [vendor running WIRE-CORE]).
- No em dashes, no exclamation marks, no emoji.

## Iconography

Stroke icons on a 24px grid, 1.75 stroke with round caps and joins, drawn in the colour of the text or state beside them (`currentColor`). Most are Lucide's own paths: `assets/Icons/README.md` names the nearest Lucide icon for each, so `lucide-react` covers them. Sizes: 16px beside 14px text, 15px in state labels and health, 13px in chips, 11px inside a step dot. Never decorative: an icon names a state, a step or an action.

## Not in the system yet

- A dark theme for the full palette.
- Charts beyond the plan bar.
- Message cards (email and Teams nudges) and the pages a vendor or a control owner sees without signing in. The prototype draws them, built from the same tokens.
- One button height. The prototype has a 40px primary on some task pages: build 38px (`size-button`).
