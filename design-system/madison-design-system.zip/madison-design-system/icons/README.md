Every icon Madison draws, as 24px stroke SVGs. The files are drawn in `ink` (#0e1c29) so they show here. In the product they take `currentColor` at a 1.75 stroke, so each is the colour of the text or state beside it.

| File | Nearest Lucide | Where Madison uses it |
| --- | --- | --- |
| `home.svg` | house | Rail: Home |
| `actions.svg` | square-check | Rail: Actions, My work |
| `tests.svg` | clipboard-check | Rail: Tests, Reviews |
| `rule-changes.svg` | table | Rail: Rule changes |
| `vendors.svg` | landmark | Rail: Vendors |
| `alerts.svg` | triangle-alert | Rail: Alerts (platform) |
| `directory.svg` | users | Rail: Directory (platform) |
| `configuration.svg` | sun-medium | Rail: Configuration (platform) |
| `all-screens.svg` | layout-grid | Prototype only: the All screens link |
| `needs-you.svg` | circle-user-round | State: Needs you, You in the Activity drawer |
| `waiting.svg` | hourglass | State: Waiting on someone |
| `madison-working.svg` | refresh-ccw | State: Madison working. Spins counter-clockwise |
| `stopped.svg` | octagon-alert | State: Stopped. Stands alone, no word |
| `at-risk.svg` | clock-3 | State: At risk, late |
| `not-started.svg` | circle-dashed | State: Not started, later |
| `paused.svg` | circle-pause | State: Madison paused, waiting on you |
| `on-time.svg` | circle-check | Health: On time |
| `check.svg` | check | Done steps, Seen, confirmed |
| `scope.svg` | file-text | Step: Scope |
| `population.svg` | database | Step: Population |
| `sample.svg` | funnel | Step: Sample |
| `evidence.svg` | paperclip | Step: Evidence |
| `decide.svg` | list-checks | Step: Test. Action: Decide |
| `sign.svg` | pen-line | Step: Conclude. Action: Sign |
| `not-in-population.svg` | file-x | Decision: Not in the population |
| `extract.svg` | table-2 | Evidence form: Extract |
| `screenshot.svg` | image | Evidence form: Screenshot |
| `calendar.svg` | calendar | View the calendar, Calendar view |
| `info.svg` | info | The rule behind a count (hover) |
| `trail.svg` | route | How Madison got here |
| `search.svg` | search | Retired from the top bar. Kept for a table's own filter |
| `ask.svg` | message-square | Ask Madison |
| `send.svg` | arrow-up | Ask Madison: send |
| `chevron-left.svg` | chevron-left | Drawer tab |
| `chevron-right.svg` | chevron-right | A row that opens a record |
| `chevron-down.svg` | chevron-down | Select, close the Ask panel |

The home, vendors, configuration and all-screens marks are the prototype's own drawings: use the Lucide name as the closest stand-in. madison-working always turns counter-clockwise when it means Madison is working now.
