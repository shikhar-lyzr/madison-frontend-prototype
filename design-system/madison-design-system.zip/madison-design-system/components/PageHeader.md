# PageHeader

A record page's title block: where it sits, what it is, and its facts on one line.

**Use** on every record page, above the StepBar. The breadcrumb names the list it came from, as a link. The title is `page-title` (24px, 700). The facts sit right, on the title's baseline: the id in mono, then the period, risk and due date separated by middle dots.

**The consumer provides** the breadcrumb, the title and the facts. A list page (Tests, Actions) has only its title, in the same style, with its segmented controls beside it.
