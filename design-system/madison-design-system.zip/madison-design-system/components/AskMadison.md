# AskMadison

A conversation about the page you are on, docked at the bottom of every page. It replaces the search bar.

**Closed**: a 560px bar centred under the content, 16px above the window's foot: Madison's mark, Ask Madison about this page, the `/` key, and send. The page leaves `space-page-bottom` (96px) under its content so the bar never covers the last row.

**Open** (click the bar, or press `/`): the bar widens to 760px and grows to 60% of the window. Its head names the page (the section and the screen). Before a question it offers up to three suggestions drawn from the page (Summarise this page, What needs me here?, What is late or stopped?). Your question sits right, in a soft bubble. Madison's answer sits left beside its mark: one sentence, then the rows or lines it drew on, each a quote that scrolls the page to that place and an Open link to the record. While it reads, the mark line says Reading this page with the working icon. Escape or the chevron closes it.

**The consumer provides** the answer service. In the prototype the answers are a mock that only quotes the page. The real agent replaces that one function and keeps the answer shape: a sentence, the items it cites, and their targets. Send is grey until there is a question, then teal. A drawer opens above the bar.
