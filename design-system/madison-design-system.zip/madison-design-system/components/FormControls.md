# FormControls

The parts of a decision: options to choose from, a reason in your words, a field or two, and a file.

**Pieces**
- `md-opt` with `md-radio`: one option per card, its name in 600 and what follows in ink-2. The chosen card takes a 1.5px ink ring on `sheet-2`. A decision never has a default unless the screen says so.
- `md-textarea`, `md-input`: on a hairline, `radius-input`. Focus is a 1.5px ink ring. Placeholders are the screen's words (Your words, Optional unless you return it).
- `md-select`: a white pill-like field with its own chevron, 30px tall.
- `md-toggle`: a 24px toggle for picking items by number (an attribute, a page). Checked is `track` with a 1.5px ink-2 ring, never a dark fill.
- `md-drop`: a dashed drop zone for a file, with what it accepts underneath.

**Rules**: the primary button stays disabled until the choices it needs are made (every radio group answered, every required field filled), then turns teal. A count beside it says how many are decided (8 of 8 decided).
