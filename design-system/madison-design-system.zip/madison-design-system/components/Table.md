# Table

Data in rows and columns, with soft dashed lines between cells and no outline at any edge.

**The grid**: 1px dashes in `grid`, 10px period, drawn between cells only. No line above the first row's head, below the last row or beside the outer columns. Column heads: 11px, 600, uppercase, 0.08em, ink-3. Cells: 13px at 1.35, `space-cell-y` by `space-cell-x`. The first and last columns lose their outside padding, so the table's text sits on the sheet's 20px text line.

**Variants**
- `is-list`: a list of records. Rows get `space-row-y` (16px) top and bottom.
- `is-home`: a Home's table. Rows are `size-row-home` (58px) and centred.
- A row that opens a record takes `data-go` with its target. The whole row is clickable, gets `hover-row` and ends with a chevron. A row that already has its own button (Decide, Ask the bank) keeps that as its action and has no chevron.
- `td.is-yours`: a 3px teal pill in the gutter left of the row. `td.is-marked`: the same pill in `mark` for a row that is marked but not yours.

**Cells hold** a subject (id in mono, then the name, 650 and ink when it is yours), RiskLevel, StateLabel, Health, StepDots and DueLane.

**Do not** truncate text with an ellipsis (a long line wraps), outline the table, or zebra-stripe rows. A short last cell beside a chevron stays on one line.
