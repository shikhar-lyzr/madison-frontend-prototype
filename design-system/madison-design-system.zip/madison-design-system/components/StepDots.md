# StepDots

A row's progress through its steps, small enough for a table cell: done dots in `done`, the current one lit in its state colour, the rest in `line`.

**Use** in a Step column, with the step's name on a line under the dots (12px, ink-2). The current dot takes a 3px `sheet-2` halo.

**The consumer provides** the step count, the current step and its state (`is-you`, `is-work`, `is-stop`, `is-risk`, `is-here` for a step that is not yours). Give it `role="img"` and an `aria-label` that names the step (Phase 4 of 6, Evidence).
