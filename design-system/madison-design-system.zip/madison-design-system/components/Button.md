# Button

The one action that is yours is a teal pill. Everything else is a white pill on a hairline, or a plain link.

**Use**
- `md-btn`: the primary action of a task. One per sheet. It carries `shadow-glow`.
- `md-btn is-secondary`: any other action in the same footer (Return, Redraft, Escalate, Refuse).
- `md-btn is-small is-secondary`: a small action beside data (Previous, Next, Seen, Retry now).
- `disabled`: the primary while its choices are not made. It turns teal the moment they are (the button waits, it never hides).
- `md-btn is-card is-tint`: the button in a Home action card at rest. It fills teal when the card is hovered or focused (see ActionCard).
- `md-link`: a way out that changes nothing (Back to the test, Full history).

**The consumer provides** the label (a verb with its object: Confirm 8 decisions, Sign the plan), an optional 16px icon before it, and the target.

**Sizes**: `size-button` 38px is the standard. `size-button-card` 36px inside cards. `size-button-small` 30px for small actions. The prototype also has a 40px primary on its round 6 task pages: build 38px.

**Do not** put two teal buttons in one sheet, use teal for a chosen option (see SegmentedControl), or style a selection as a button.
