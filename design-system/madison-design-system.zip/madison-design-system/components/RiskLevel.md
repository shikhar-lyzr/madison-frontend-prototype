# RiskLevel

A control's inherent risk as a soft pill with three signal bars, filled to its level.

**Use** in a Risk column and on a plan. High is `level-high` on `level-high-soft`, Medium is `risk` on `risk-soft`, Low is `wait` on `wait-soft`.

**The consumer provides** the level. The bars are drawn in `currentColor`: filled bars at full opacity, the rest at 0.22. Give the column 84px so the pill never wraps. Anything else the cell says (a dependency band) goes on a line under the pill in ink-3, 12px.
