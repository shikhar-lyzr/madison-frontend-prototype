# StateLabel

Who has an item now, in one line: the state's icon and name in its colour, then the reason in ink-2.

**The five states**
- Needs you (`you`): your move.
- Waiting on someone (`wait`): name the person or role.
- Madison working (`work`): the only state that moves. Its icon spins counter-clockwise, 4s a turn.
- Stopped (`stop`): the octagon stands alone. Do not repeat the word Stopped, write only the reason after it.
- Not started (`ink-3`, the dashed circle).

Late is not a state: it is a fact after the reason, in `risk` at weight 600 (18 days late).

**The consumer provides** the state, the name (Waiting on David Nkemelu) and the reason. Separate parts with a middle dot. Text from the screen only.
