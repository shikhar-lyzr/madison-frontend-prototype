# PlanBar

One bar for a plan or a position in every section: a segment per count, as wide as its count, in the tint of what it counts.

**Use** under a plan's big number (`figure`): Assurance's plan (in progress, not started), Regulatory change's four counts (covered, not yet confirmed, nothing behind it, known gap) and Third parties' share of the plan.

**Kinds**: `is-ok` (`ok-soft`), `is-work` (`work-soft`), `is-risk`, `is-stop`, `is-wait`, and no class for a count still to start (`line-2`). A count of zero stays grey. A segment with no words inside takes the deeper tint (`ok-deep`, `work-deep` and so on) so its count still shows.

**The consumer provides** each count, its label (the screen's words, with the count) and its link. Segments 3px apart, 32px tall, the whole bar a pill. Give it `role="img"` and an `aria-label` with every count.
