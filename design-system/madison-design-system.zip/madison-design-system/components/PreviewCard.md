# PreviewCard

A small card that shows what a link opens before you follow it.

**Use** on a link whose target is a long record (How Madison got here). It appears on hover and on keyboard focus, never open at rest, so it does not cover the page.

`sheet`, `radius-card`, `shadow-peek`, 290px wide, 12px text at 1.45. Title row: the name in 600 and its id in mono on the right, on one line. Above the link, 10px clear.

**The consumer provides** the title, the id and one or two lines of summary.
