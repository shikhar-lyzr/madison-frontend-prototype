# Rail

The left navigation: the product, its sections and their screens, and who you are.

**Structure**: Madison in the `wordmark` style with the bank under it, then one block per section. The section you are in is live (36px items, 14px, its name in ink-2), the others are quiet (32px items, 13px, name in ink-3). The page you are on is a white pill on a hairline, weight 600, never a dark fill. A count that needs you is a teal badge, any other count is mono ink-2 text. At the foot: the person, their role, and the demo date.

**In the product** each section is its own app and shows only its own block. The prototype shows all three (Regulatory change, Assurance, Third parties, in that order) so one link reaches every screen, and adds an All screens link that is not part of the product.

**The consumer provides** the sections, their items with icon, label, target and count, and the person. Width `space-rail` (220px). The content starts `space-page-left` (10px) after it.
