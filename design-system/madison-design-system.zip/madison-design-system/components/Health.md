# Health

Whether a test or review will finish by its due date: On time in green, At risk in amber, a stop with its reason in red.

**Use** in a Health column. `ok` is a green set apart from the `you` teal so that On time never reads as yours. The column head carries an info icon whose hover gives the rule behind the health.

**The consumer provides** the health and, for a stop, the reason (the word Stopped is not repeated).
