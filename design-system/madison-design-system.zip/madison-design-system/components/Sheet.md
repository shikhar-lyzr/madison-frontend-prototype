# Sheet

Every block of content sits on a sheet. Who has the item decides how the sheet looks.

**The rule (T1)**: what is yours is raised, everything else lies flat, a stop is raised in red. Accent appears only on what is yours.
- `md-sheet is-raised`: your task. `sheet` with `shadow-lift`.
- `md-sheet is-flat`: not yours (view only, waiting, history). `flat` with the `shadow-ring` hairline.
- `md-sheet is-stop`: stopped. `sheet` with `shadow-stop`.
- `md-inner`: a panel inside a sheet (`sheet-2`, `radius-inner`). Never a hairline.

**Layout**: padding `space-panel-y` by `space-panel-x` (16px by 20px). Every line of text inside a sheet starts on that 20px line, table text included. Sheets sit `space-panel-gap` (14px) apart. A sheet's head row holds a tag, the step name, and the time on the right (Since, Ran, Stopped).

**The consumer provides** the content. Do not nest a raised sheet inside another sheet, or give a sheet a coloured left border.
