# Drawer

The Activity drawer: who has this record and what happened to it, one tab away on every record page.

**Use** on every record page. Closed, only its tab shows at the right edge (`Activity`, written vertically). Open, it floats 14px in from the top, right and bottom, 330px wide, over a `scrim`. Escape, the scrim or the tab closes it. A closed drawer casts no shadow.

**Contents, in order**: the title, Who has this (one row per person or Madison, yours tinted `you-soft`), What happened (newest first, the newest dot filled in your colour or Madison's), then a link to the full history and How Madison got here.

**The consumer provides** the people with what each is doing, the events with date, actor and action, and the history link. Slide: `duration-drawer` with `ease-drawer`. The open drawer sits above the Ask bar (`z-drawer-open`).

A finished step in the step bar with no record of its own opens this drawer.
