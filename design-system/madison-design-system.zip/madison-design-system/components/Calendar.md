# Calendar

The plan as time: one row per item, today as a line, each item's time left as a line from today to its due tick, and its state today as a dot on today's line.

**Use** for Tests (Calendar view) and Position (Calendar). The key sits above the rows, never below, so a long list cannot push it out of view.

**Rows**: `size-calendar-row` (58px), the name column 250px, the due column 110px, months as faint `line-2` rules. A row that opens a record takes `data-go`, is clickable as a whole and ends with a chevron. The state dot uses the state's colour: ringed for yours, `work` for Madison, filled `stop` for a stop, dashed for waiting.

**The consumer provides** the year's months, today, and per item its name, state and due date.
