# DueLane

How far a test has to run before its due date, drawn in a table cell: a track, the time used so far, a dot for today and the due date in mono.

**Use** in a Home table's Due column (150px). The lane takes the row's health colour: `stop` or `risk` when the health says so, ink when the row is yours, ink-3 otherwise.

**The consumer provides** the share of the period used (a percentage: days elapsed over the period, scaled so the date fits) and the due date.
