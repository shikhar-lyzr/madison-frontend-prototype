# Tag

A short word that says what a sheet or a card is, above its title.

**Use**
- `md-tag is-you`: Your task now. Only on a sheet that is yours.
- `md-tag`: View only, Workpaper, Outcome, Now. A sheet that is not yours.
- `md-tag is-stop`: Stopped, on a stopped sheet.
- `md-tag is-step`: the step a Home action card is at (Evidence, Scope, Review). Teal when the card is yours.
- `md-label`: a small grey label inside a row: a certainty (Clear, Likely, Unsure), a design gap.

**The consumer provides** one or two words from the screen, and an optional 13px icon.

Tags are 12px, weight 700 (600 for `is-step`), on `radius-tag`. They never act: no hover, no pointer.
