# StepBar

Where a record is in its process: one station per step, on one line, under the page header.

**Stations**
- Done: a 22px `done` disc with a check. It opens that step's view-only record (Script, Population, Sample). With no record of its own, it opens the Activity drawer.
- Late: a 22px ring in `risk`, done but late. The lateness follows the sub line in `risk` (41 of 45 · 18 days late).
- Now, yours: a 32px `you` disc that pulses (`duration-pulse`). Its name in teal, 700.
- Now, Madison's: a 32px `work-soft` disc with a dashed `work` ring that turns slowly (`duration-ring`).
- Now, not yours: a 28px white disc ringed in ink-2.
- Stopped: a 32px `stop` disc. Its sub line says what stopped it, in `stop`.
- To come: a 22px dashed circle in ink-3, its name in ink-2.

**The track**: done steps joined by a solid `done` line, the stretch into the current step in dashes of the current colour that flow toward it (`duration-flow`, still when stopped), the rest in `line`.

**The consumer provides** each step's name, its sub line, its state and, for a finished step, the record it opens. A finished step shows a halo and an underline under the pointer.
