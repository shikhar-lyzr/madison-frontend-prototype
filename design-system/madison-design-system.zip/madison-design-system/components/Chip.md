# Chip

A filter over a list by state: the state's icon, its name and a count.

**Use** above a list (Tests, Rule changes, Reviews, Vendors). Not on a Home: a Home's table carries no chips, its All tests link leads to the list that has them.

**The consumer provides** the state, its label and its count. Order: All, then what needs attention (Stopped, At risk), a hairline (`md-chip-rule`), then who has it (Needs you, Waiting on others, Madison working, Not started, Concluded).

**Rules**
- Stopped, At risk and Needs you are tinted (`stop-soft`, `risk-soft`, `you-soft`). The rest sit on a hairline with their icon in the state colour.
- The chosen chip is white with `shadow-chip-selected`, never a dark fill.
- The Madison working icon turns counter-clockwise (`md-spin`), the way its arrows point.
- stop on stop-soft is 4.2:1 and risk on risk-soft 4.4:1: keep chip text at 12px, weight 600.
