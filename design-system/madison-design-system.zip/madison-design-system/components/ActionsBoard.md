# ActionsBoard

Everything that needs a person, in two columns: To do (Madison cannot go on without you) and Worth a look (Madison went on, you may want to check). There is no Done tab.

**Rules**
- To do holds action cards (see ActionCard). What you finished stays at the foot of To do, struck through and faded, newest first, with its time.
- Worth a look holds flat items with Open and Seen. Seen strikes the item through, drops it to the foot of its column and lowers the column's count.
- Items never move between the two columns, and there is no dragging: the columns are two kinds of work, not stages.
- Column heads: the name in `section-title`, the count in mono ink-3. The columns are `space-columns` (24px) apart.

**The consumer provides** the to-do items, the look items, and the done items with their time. Changed after the 30 Sep designer review, which asked for the to-do list style of Apple Reminders.
