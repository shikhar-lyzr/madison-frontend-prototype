# EmptyState

What a list says when there is nothing for you: one sentence, with what is still going on.

**Use** under a section title when its list is empty (Your actions · 0). `sheet` with a 1px dashed `line` border, `radius-card`, 13px ink-2.

**The consumer provides** the sentence. Say what is true and what is running, not an invitation (Nothing needs you. 5 tests are running.).
