# ActionCard

One thing on a Home that needs you: what it is, where it stands, how long it has waited, and the one button that opens it.

**Use** under Your actions on a Home, two or three across (`space-grid` apart), and in the To do column of the Actions board.

**States**: at rest the card lies open on a hairline and its button is a soft tint, so a Home with several actions does not shout. Under the pointer or keyboard focus the card lifts (`shadow-lift`, 2px up) and its button fills teal. The right card above shows that state. This replaces the earlier always-raised card, after the 30 Sep designer review.

**The consumer provides** the id (mono), the name, the risk, the step tag, one line of what is needed, the since line, and the button's verb and target.

**Do not** use it for a stopped item: a stop keeps `md-sheet is-stop` so its red ring is not lost.
