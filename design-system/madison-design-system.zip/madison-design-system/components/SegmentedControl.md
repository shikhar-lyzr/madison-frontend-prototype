# SegmentedControl

A choice of view, never an action: options in a grey track, the chosen one a white raised pill.

**Use** for Calendar or List, Mine or Whole team, a section's stages (New rules, In progress, Coverage), and a record's tabs set as a group (Four counts, Orphans, Calendar).

**The consumer provides** two to six options, each a link (`aria-current="page"`) or a toggle button (`aria-pressed="true"`), an optional icon and a count in mono.

**Rules**
- The track is `track`. The chosen option is `sheet` with `shadow-selected` and weight 600. Options at rest are transparent, weight 400.
- A chosen option is never teal and never a dark fill. Teal means an action that is yours. A designer review (30 Sep) found dark selected states read as buttons.
- Keep the labels the screen's own words. Counts follow the label (New rules 4).
